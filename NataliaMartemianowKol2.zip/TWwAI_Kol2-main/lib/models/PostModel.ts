import mongoose, { Schema, Document } from 'mongoose';

interface IPost extends Document {
    pressure: string;
    temperature: string;
    humidity: string;
    date: string;
}

const PostSchema = new mongoose.Schema({
    temp: {type: String},
    humidity: {type: String},
    pressure: {type: String},
    date: {type: String}
}, {
    collection: 'paramsNM'
});

const PostModel = mongoose.model<IPost>('PostNM', PostSchema);

async function query() {
    return PostModel.find({});
}
async function add() {
    return PostModel.create();
}

export default {
    query:query,
    add:add,
    model:PostModel
};
